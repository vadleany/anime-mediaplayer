local PANEL = {}
PANEL.HistoryWidth = 300
PANEL.BackgroundColor = Color(22, 22, 22)

AccessorFunc( PANEL, "m_MediaPlayer", "MediaPlayer" )

function PANEL:Init()

	self:SetPaintBackgroundEnabled( true )
	self:SetFocusTopLevel( true )

	local w = math.Clamp( ScrW() - 100, 800, 1152 + self.HistoryWidth )
	local h = ScrH()
	if h > 800 then
		h = h * 3 / 4
	elseif h > 600 then
		h = h * 7 / 8
	end
	self:SetSize( w, h )

	self.CloseButton = vgui.Create( "DIconButton", self )
	self.CloseButton:SetSize( 32, 32 )
	self.CloseButton:SetIcon( "mp-close" )
	self.CloseButton:SetColor( Color( 250, 250, 250, 200 ) )
	self.CloseButton:SetZPos( 5 )
	self.CloseButton:SetText( "" )
	self.CloseButton.DoClick = function ( button )
		self:Close()
	end

	self.BrowserContainer = vgui.Create( "DPanel", self )
	self.BrowserContainer:Dock( FILL )

	self.Browser = vgui.Create( "DMediaPlayerHTML", self.BrowserContainer )
	self.Browser:Dock( FILL )

	self.Browser:AddFunction( "gmod", "requestUrl", function (url)
		MediaPlayer.MenuRequest( url )
		self:Close()
	end )

	self.Browser:AddFunction( "gmod", "openUrl", function (url)
		gui.OpenURL( url )
	end )

	self.Browser:AddFunction( "gmod", "clickSound", function (click)
		surface.PlaySound( click and "garrysmod/ui_click.wav" or "garrysmod/ui_hover.wav" )
	end )

	self.Browser:AddFunction( "gmod", "getServices", function ()
		local mp = self.m_MediaPlayer

		if mp then
			self:SendServices( mp )
		end
	end )

	local requestUrl = MediaPlayer.GetConfigValue( "request.url" )
	local lang = MediaPlayer.i18n.GetLanguage()
	self.Browser:OpenURL( requestUrl .. "#lang=" .. lang )

	self.Controls = vgui.Create( "MPHTMLControls", self.BrowserContainer )
	self.Controls:Dock( TOP )
	self.Controls:DockPadding( 0, 0, 32, 0 )
	self.Controls:SetHTML( self.Browser )
	self.Controls.BorderSize = 0
	self.Browser._Controls = self.Controls
	self.Controls.BorderSize = 0

	hook.Add( "GUIMousePressed", self, self.OnGUIMousePressed )
	hook.Add( "VGUIMousePressed", self.Browser, self.OnVGUIMousePressed)

end

function PANEL:SetMediaPlayer( mp )
	self.m_MediaPlayer = mp
end

function PANEL:Paint( w, h )

	surface.SetDrawColor( self.BackgroundColor )
	surface.DrawRect( 0, 0, w, h )

	return true

end

function PANEL:OnRemove()
	hook.Remove( "GUIMousePressed", self )
	hook.Remove( "VGUIMousePressed", self.Browser )
end

function PANEL:Close()
	if IsValid(self.Browser) then
		self.Browser:Remove()
	end

	self:OnClose()
	self:Remove()
end

function PANEL:OnClose()

end

function PANEL:CheckClose()

	local x, y = self:CursorPos()

	if not (gui.IsGameUIVisible() or gui.IsConsoleVisible()) and
		( x < 0 or x > self:GetWide() or y < 0 or y > self:GetTall() ) then
		self:Close()
	end

end

function PANEL:PerformLayout( w, h )

	self.CloseButton:SetPos( w - 36, 2 )

end

function PANEL:OnGUIMousePressed( key )

	if key == MOUSE_LEFT then
		self:CheckClose()
	end

end

function PANEL:OnVGUIMousePressed( pnl, key )
	if not IsValid(pnl) then return end
	if not IsValid(self._Controls) then return end

	if key == MOUSE_4 then
		self._Controls.Navigating = true
		self._Controls:HTMLBack()
	elseif key == MOUSE_5 then
		self._Controls.Navigating = true
		self._Controls:HTMLForward()
	end

end

function PANEL:OnKeyCodePressed( key )
	if key == KEY_ESCAPE then
		self:Close()
	end
end

vgui.Register( "MPRequestFrame", PANEL, "EditablePanel" )